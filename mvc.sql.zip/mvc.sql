-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2017 at 01:49 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Trong nước'),
(2, 'Quốc tế'),
(4, 'Văn hóa'),
(5, 'Thể thao'),
(6, 'Công nghệ'),
(7, 'Quân sự'),
(8, 'Tự sự');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL DEFAULT '1',
  `category_id` int(11) NOT NULL DEFAULT '1',
  `content` text,
  `thumbnail` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `time`, `user_id`, `category_id`, `content`, `thumbnail`) VALUES
(1, 'Real - Barca: Chiến cuộc cuối cùng của chiến binh Luis Enrique', '2017-04-26 13:46:43', 1, 1, 'Bạn có biết bộ phim nổi tiếng \"300\" do Zack Snyder đạo diễn là một sản phẩm... chém gió quá đà? Không như trên phim, trận chiến Thermopylae có đến 7.000 người Hy Lạp tham chiến. Sau khi bị phản bội, Vua Leonidas quả là có ở lại chặn quân Ba Tư cùng với 300 chiến binh Spartan. Nhưng bên cạnh đó còn có 700 người Thespian, 400 người Theban và mấy trăm quân của các thành bang Hy Lạp khác. Để trận đánh thêm phần bi tráng, các nhà biên kịch ở Hollywood chỉ giữ lại 300 quân Spartan mà thôi.\r\n\r\nNhưng lịch sử thực sự đã chứng kiến có cuộc chiến khác của 300 chiến binh đấu lại thiên binh vạn mã, diễn ra vào năm 722. Lãnh đạo cuộc khởi nghĩa là Don Pelayo, quý tộc người Visigoth đã khai sinh Vương quốc Asturias (tiền thân của nước Tây Ban Nha ngày nay). Bị dồn lên núi Auseva nhưng Don Pelayo và tàn binh của ông kiên quyết không hạ vũ khí. Họ đánh đến cùng và khi tàn cuộc, Pelayo vẫn sống, bên cạnh 10 người của quân mình. Và ở ngọn núi lịch sử năm nào, người ta đã dựng một bức tượng của Pelayo, tay cầm thanh gươm với gương mặt can trường, tự hào và bất khuất.\r\n\r\nVì sao trước một trận El Clasico lại kể truyện lịch sử? Vì Luis Enrique chính là một người Asturia.\r\n\r\nKhi Barcelona đến sân Real Madrid, dường như Enrique thấy mình đang rơi vào tình thế của Pelayo ngày trước. Barca đã bị loại khỏi Champions League, thất bại ở El Clasico sẽ chấm dứt nốt hy vọng của họ tại La Liga. Khi ấy, hàng vạn mũi giáo của truyền thông sẽ xiên vào người ông. Nhưng sự can trường là điều ta có thể thấy ở Enrique.\r\n\r\n\"Sau một thất bại, thật khó để kích thích các cầu thủ. May thay đối thủ tiếp theo lại là Real Madrid\", Enrique nói. \"Tôi là một chiến binh, tôi chuẩn bị cho mọi thứ, đặc biệt là những thứ gian khó. Tôi có gene của người Asturia, tôi có gene của Pelayo. Tôi cảm thấy thoải mái hơn khi bị rơi vào thế phải phản kháng. Tôi sẽ tận hưởng trận đấu này, vì tôi cảm thấy thoải mái hơn khi thấy mình đứng trong một cuộc chiến\".\r\n\r\nreal-barca-chien-cuoc-cuoi-cung-cua-chien-binh-luis-enrique-1\r\nEnrique và các học trò đang ở vào một tình thế ngặt nghèo, khi chỉ còn mỗi La Liga để níu giữ cho mùa giải này.\r\nVà đấy không chỉ là một cuộc chiến thông thường, nó là cuộc chiến lớn nhất lịch sử bóng đá thế giới, được đặt vào tình thế ngặt nghèo nhất, nơi triều đại của Enrique ở Barca đang đi vào hồi cuối. Và Enrique lại là người cũ của Real. Không có một sự nhân từ nào từ các khán đài dành cho kẻ phản bội trong chuyến trở về này.\r\n\r\nThực tế thì Enrique luôn cảm thấy... thoải mái khi bị các Madrisita xem như kẻ phản bội. Ông bảo khi nhìn lại những bức ảnh ngày cũ thuở còn đá cho Real, ông đã không nhận ra chính mình: \"Tôi thấy màu áo xanh-đỏ (Barca) hợp với mình hơn nhiều\".', 'http://img.f32.vnecdn.net/2017/04/26/ongthamphan-1493190052_500x300.jpg'),
(2, 'Triều Tiên tuyên bố sẵn sàng đánh chìm tàu sân bay Mỹ', '2017-04-26 13:47:12', 1, 1, 'Tổng thống Mỹ Donald Trump trong tháng 4 ra lệnh điều nhóm tác chiến tàu sân bay USS Carl Vinson tới gần bán đảo Triều Tiên để ứng phó với căng thẳng gia tăng liên quan đến Triều Tiên. Phó tổng thống Mỹ Mike Pence ngày 22/4 nói cụm tàu sẽ đến nơi \"trong vài ngày tới\" và không nêu chi tiết.\r\n\r\n\"Các lực lượng cách mạng của chúng ta sẵn sàng chiến đấu để đánh chìm một tàu sân bay hạt nhân Mỹ chỉ bằng một đòn\", Rodong Sinmun, tờ báo của đảng Lao động Triều Tiên, hôm nay cho biết trong một bài bình luận.\r\n\r\nBài bình luận ví USS Carl Vinson là \"loài vật to béo\" và tấn công con tàu là \"ví dụ thực tế để phô diễn sức mạnh quân sự\". Bài được đăng trên trang thứ ba của tờ báo, sau hai trang viết về nhà lãnh đạo Kim Jong-un.\r\n\r\nNhóm tác chiến tàu sân bay USS Carl Vinson\r\n\r\n\r\nTriều Tiên sẽ kỷ niệm 85 năm ngày thành lập Quân đội Nhân dân vào ngày 25/4. Nhiều chuyên gia cho rằng Bình Nhưỡng có thể thử hạt nhân hoặc tên lửa vào dịp này. Triều Tiên đã thử hạt nhân 5 lần và phóng thử nhiều tên lửa đạn đạo.\r\n\r\nTổng thống Trump tuyên bố sẽ ngăn Triều Tiên đạt được khả năng tấn công Mỹ bằng tên lửa hạt nhân, cảnh báo không loại trừ biện pháp nào, kể cả tấn công quân sự. Triều Tiên cũng dọa tấn công hạt nhân Mỹ nếu Washington có hành động khiêu khích.', 'http://img.f32.vnecdn.net/2017/04/26/chu-tich-nuoc-2-7581-1493202077_500x300.jpg'),
(3, 'Apple Watch 3, iPhone mới sẽ dùng màn hình micro LED', '2017-04-26 13:48:03', 1, 1, 'Theo Business Korea, Apple đang làm việc với LuxVue để phát triển và ứng dụng màn hình micro LED mới, sau khi mua lại công ty này từ năm 2014.\r\n\r\nMicro LED được đánh giá là công nghệ đột phá, sở hữu các đặc tính như nhẹ hơn, mỏng hơn và hiển thị tốt hơn so với các dòng màn hình hiện nay. Trước thương vụ của Apple, hầu như chưa được ai biết đến công nghệ này.\r\n\r\napple-watch-3-iphone-moi-se-dung-man-hinh-micro-led\r\nCông nghệ micro LED sẽ là hướng đi của Apple trong tương lai. Ảnh minh họa.\r\nTháng 2/2017, Apple đã đăng ký bằng sáng chế tích hợp đầu đọc vân tay lên bề mặt màn hình micro LED nhờ đưa vào các cảm biến diot hồng ngoại. Đây được xem là giải pháp giúp tích hợp Touch ID lên màn hình mà hãng ấp ủ từ lâu.\r\n\r\niPhone 8 dự kiến trình làng cuối năm nay có thể sẽ áp dụng công nghệ tương tự. Tuy nhiên, những khó khăn trong việc sản xuất micro LED cỡ lớn có thể khiến điều này bị trì hoãn. Trước đó, micro LED sẽ được mang lên Apple Watch 3.\r\n\r\nĐộng thái của Apple cũng cho thấy iPhone đời mới dùng màn hình OLED có thể chỉ là bước đi tạm thời trước khi hãng áp dụng công nghệ micro LED.\r\n\r\napple-watch-3-iphone-moi-se-dung-man-hinh-micro-led-1\r\nApple Watch 3 có thể là sản phẩm đầu tiên của Apple dùng màn hình micro LED. Ảnh minh họa.\r\nHơn nữa, công ty công nghệ Mỹ sẽ không mua màn hình OLED từ Samsung mà chuyển sang sản xuất ở Trung Quốc. Ngoài việc mất đi hợp đồng cung ứng trị giá hàng tỷ USD, Samsung và LG cũng đứng trước lo ngại khi Apple bắt đầu tìm nguồn cung cấp RAM hay camera từ các đối tác khác.\r\n\r\nThông báo cho biết Apple đang đàm phán mua lại bộ phận kinh doanh chip nhớ của Toshiba, chấm dứt hai thập kỷ trở thành khách hàng lớn nhất của Samsung.\r\n\r\nGiới công nghệ Hàn Quốc cho rằng nỗ lực tăng cường tự sản xuất các thành phần và đa dạng hóa các nhà cung ứng sẽ ảnh hưởng nghiêm trọng đến ngành công nghiệp của nước này. Apple hiện mua 2,63 tỷ USD linh kiện từ Hàn Quốc.\r\n\r\nNguồn lợi từ Apple cho các công ty Hàn Quốc có thể sẽ kết thúc trong 2-3 năm tới, phần lớn do chịu cạnh tranh từ Trung Quốc trong lĩnh vực bán dẫn và màn hình.', 'http://img.f7.sohoa.vnecdn.net/2017/04/26/476517-applewatch-2880-1493180722_180x108.jpg'),
(4, '14.000 công ty dùng Facebook làm nền tảng kết nối', '2017-04-26 13:48:33', 1, 1, 'Sau 6 tháng ra mắt chính thức, Facebook Workplace đã thu hút 14.000 doanh nghiệp và tổ chức sử dụng với hơn 400.000 nhóm được tạo ra.\r\nWorkplace là nền tảng truyền thông chuyên biệt, giúp người dùng trong một công ty kết nối, giao tiếp nội bộ và hợp tác với nhau trong công việc. Bắt đầu được thử nghiệm từ năm 2015 với tên gọi Facebook At Work, Workplace chính thức ra mắt vào tháng 10/2016 với hơn 1.000 doanh nghiệp đăng ký sử dụng. \r\n\r\nTại hội thảo F8, diễn ra tuần trước ở San Jose (Mỹ), Facebook công bố sau sáu tháng, số lượng tổ chức, doanh nghiệp sử dụng đã tăng lên 14.000 với hơn 400.000 nhóm được tạo ra. \r\n\r\nÔng Ramesh Gopalkrishna, Phụ trách khu vực châu Á - Thái Bình Dương của Facebook, cho biết nền tảng này tích hợp sâu với các dịch vụ như Box, Office 365, Dropbox, Salesforce/Quip. Nhờ đó, người dùng không cần tải file lên một dịch vụ lưu trữ rồi dán đường link vào nhóm Facebook, mà họ có thể chia sẻ file trực tiếp để đồng nghiệp nhanh chóng bấm vào xem, chỉnh sửa và bình luận. \r\n\r\nBên cạnh bản thu phí Workplace Premium với giá 1-3 USD/người dùng mỗi tháng, Facebook mới đây cũng trình làng gói Workplace Standard miễn phí cho cho doanh nghiệp nhỏ.', 'http://img.f5.sohoa.vnecdn.net/2017/04/25/FB-9189-1493110052.jpg'),
(5, 'Galaxy Note 7 sắp được bán trở lại với giá 620 USD', '2017-04-26 13:48:58', 1, 1, 'Để phân biệt với phiên bản cũ, Galaxy Note 7 tân trang sẽ được gọi với tên Note 7R (Refurbished). Máy giảm dung lượng pin từ 3.500 mAh xuống còn 3.200 mAh, theo PhoneArena.\r\n\r\ngalaxy-note-7-sap-duoc-ban-tro-lai-voi-gia-620-usd\r\nNote 7 sẽ trở lại thị trường Hàn Quốc dưới dạng hàng tân trang, giá giảm 30%.\r\nPhần cứng và ngoại hình của Note 7 tân trang được cho là không thay đổi. Máy dùng màn hình Quad HD 5,7 inch Super Amoled, bộ xử lý Exynos 8890, RAM 4 GB, bộ nhớ trong 64 GB và camera 12 megapixel.\r\n\r\nMức giá cho Galaxy Note 7R tại thị trường Hàn Quốc là 620 USD (khoảng 14 triệu đồng), giảm 30% so với giá 875 USD (khoảng 20 triệu đồng) của Note 7 trước đây.\r\n\r\nTại Việt Nam, Note 7 lên kệ tháng 8/2016 với giá 19 triệu đồng. Nếu áp mức giảm tương tự 30%, phiên bản tân trang có thể được bán trong nước giá 13,3 triệu đồng.\r\n\r\nTuy nhiên, chưa có thông tin về việc Note 7R được bán tại Việt Nam. Trao đổi với VnExpress vào tháng 2/2017, đại diện Samsung Việt Nam cho biết hãng hiện không có kế hoạch bán Galaxy Note 7 tân trang.', 'http://img.f5.sohoa.vnecdn.net/2017/04/26/galaxy-note-7-1-1896-1493194752.jpg'),
(6, 'Triều Tiên kêu gọi ASEAN ngăn chặn \'thảm họa diệt chủng hạt nhân\'', '2017-04-27 11:31:44', 1, 1, 'Trong lá thư gửi tổng thư ký Hiệp hội các quốc gia Đông Nam Á (ASEAN), Bình Nhưỡng cảnh bảo về tình hình căng thẳng trên bán đảo Triều Tiên \"đang tiến tới bờ vực chiến tranh\", AFP dẫn lời Bộ trưởng Ngoại giao Triều Tiên Ri Yong-Ho.\r\n\r\nÔng Ri thúc giục người đứng đầu ASEAN thông báo tới 10 nước trong khối về \"tình hình nghiêm trọng\" hiện nay. Trong thư đề ngày 23/3, bộ trưởng Ri cũng chỉ trích việc Mỹ và Hàn Quốc tập trận chung.\r\n\r\n\"Tôi bày tỏ mong muốn ASEAN, với thái độ coi trọng việc gìn giữ hòa bình và ổn định trong khu vực, sẽ đứng ở vị trí khách quan để lên tiếng về các cuộc tập trận chung giữa Mỹ và Hàn Quốc tại hội nghị của ASEAN, đồng thời sẽ đóng vai trò tích cực trong việc bảo vệ hòa bình và an toàn trên Bán đảo Triều Tiên\", theo bức thư được gửi đi trước thềm Hội nghị cấp cao ASEAN diễn ra từ ngày từ 26-29/4 tại Manila, Philippines.\r\n\r\nTriều Tiên có mối quan hệ gần gũi với một số nước thành viên ASEAN, bao gồm Campuchia và Lào.\r\n\r\nQuan hệ ngoại giao giữa Bình Nhưỡng và Kuala Lumpur đã trở nên căng thẳng khi hai bên tranh cãi về về cuộc điều tra vụ mưu sát người đàn ông được cho là anh cùng cha khác mẹ của lãnh tụ Triều Tiên Kim Jong-un.', 'http://img.f29.vnecdn.net/2017/04/27/trumpandkimun-9155-1493288912.jpg'),
(7, 'Giới quan sát lo Duterte \'chiều lòng\' Trung Quốc ở Cấp cao ASEAN', '2017-04-27 11:32:15', 1, 1, '\"Chủ tịch ASEAN năm nay, Philippines, dường như sẽ đưa ra quan điểm ôn hòa về tranh chấp Biển Đông trong hội nghị cấp cao đầu tiên\", chuyên gia Richard Javad Heydarian, Đại học De La Salle, Philippines, nói với VnExpress khi nhắc tới Hội nghị cấp cao Hiệp hội các quốc gia Đông Nam Á (ASEAN) sắp tới.\r\n\r\nCấp cao ASEAN lần thứ 30 và các hội nghị liên quan sẽ diễn ra tại Manila trong hai ngày 28/4 và 29/4, với sự tham gia của lãnh đạo của các nước thành viên ASEAN.\r\n\r\nCó trong tay tài liệu dự thảo về tuyên bố của chủ tịch ASEAN, ông Heydarian lưu ý cụm từ \"áp dụng đầy đủ các tiến trình pháp lý và ngoại giao\" là quan điểm đồng thuận với mẫu thức chung ở mức thấp nhất mà ASEAN đã đạt được từ đầu năm 2016. Vấn đề đã được nêu lên trong hội nghị giữa lãnh đạo Hiệp hội với Tổng thống Mỹ vào thời điểm năm ngoái là Barack Obama tại Sunnylands.\r\n\r\nĐáng chú ý, nó được nêu lên trước khi Tòa trọng tài quốc tế tháng 7/2016 tuyên bố Philippines thắng kiện Trung Quốc, trong đó bác bỏ yêu sách đường lưỡi bò của Bắc Kinh ở Biển Đông. Thực tế là Philippines tỏ ra chậm trễ trong việc định hình và chỉ đạo cuộc thảo luận trong khu vực.\r\n\r\nTừ đó, chuyên gia Philippines cho rằng thảo luận về tranh chấp sẽ không có tiến triển. Tổng thống Philippines Duterte sẽ trung thành với mẫu thức chung nói trên, chỉ nói về \"tiến trình pháp lý\", tôn trọng Công ước luật biển năm 1982 của Liên Hợp Quốc (UNCLOS). Thậm chí ông Duterte cũng sẽ không đề cập tới phán quyết của Tòa trọng tài.\r\n\r\n\"Chính quyền của ông Duterte không muốn gây xáo trộn việc cải thiện quan hệ với Trung Quốc và tránh làm mất lòng các thành viên ASEAN thân thiện với Bắc Kinh\", ông Heydarian nhấn mạnh.\r\n\r\nTổng thống Philippines từ khi lên nắm quyền đã thể hiện rõ quan điểm muốn có quan hệ gần gũi với Trung Quốc. Ông Duterte khẳng định chỉ có Trung Quốc mới giúp được Philippines, đặc biệt là xây dựng nền kinh tế, khi ông Duterte có những kế hoạch xây dựng cơ sở hạ tầng lớn nhưng thiếu vốn. Nhà lãnh đạo Philippines thẳng thắn cho biết sẽ không gây chiến với Trung Quốc vì tranh chấp trên biển, thừa nhận không thể ngăn Bắc Kinh xây dựng các cơ sở trên bãi cạn Scarborough, khu vực hai nước có tranh chấp, thậm chí cho biết Manila sẵn lòng chia sẻ các tài nguyên trong khu vực nước này có đặc quyền ở Biển Đông với Trung Quốc. Các quan chức Philippines tiết lộ nước này và Trung Quốc sẽ thảo luận trực tiếp về Biển Đông trong tháng 5. Trong khi quan điểm chung của ASEAN là cần có đàm phán đa phương, có sự tham gia của các nước liên quan. ', 'http://img.f29.vnecdn.net/2017/04/27/du2-2198-1493265846.jpg'),
(8, 'Triều Tiên nhìn từ thành phố viễn biên Trung Quốc', '2017-04-27 11:33:07', 1, 1, 'Mặt trời mọc trên cầu Hữu Nghị vượt sông Áp Lục, nối hai bờ biên giới Triều - Trung. \r\nÁp Lục là con sông phân chia biên giới Triều Tiên và Trung Quốc. Tháng 7/2016, Trung Quốc khai trương tour du lịch miễn visa và hộ chiếu tới Sinuiju, thành phố biên giới Triều Tiên. Tuyến du lịch thu hút hơn 20.000 lượt khách mỗi ngày. Khách tham quan đến từ 40 quốc gia, người Trung Quốc chiếm tỷ lệ 85%.\r\n \r\n \r\nMột khu chung cư cao cấp tại Đan Đông. Đứng từ trên nhà cao tầng ở đây có thể nhìn thấy quang cảnh Sinuiju phía bên kia Triều Tiên.\r\nĐan Đông thuộc tỉnh Liêu Ninh, là thành phố biên giới lớn nhất Trung Quốc, có đường biên giới dài 206 km với Triều Tiên, cửa khẩu giao thương lớn nhất của Trung Quốc với Triều Tiên. \r\n \r\n \r\nCầu Áp Lục là tuyến đường vận tải tiếp tế chính của Trung Quốc sang nước láng giềng trong chiến tranh Triều Tiên. Năm 1950, cầu trúng bom Mỹ, nay chỉ còn lại 4 nhịp, được gọi là cầu Gãy. Ngày nay, cầu trở thành điểm du lịch, nơi du khách thường tới nhìn ngắm Triều Tiên qua kính viễn vọng. Bỏ ra 5 tệ (0,8 USD), mỗi người có thể sử dụng trong hai phút.\r\n \r\n \r\nNgười Trung Quốc đi bộ trên đoạn Cầu Gãy.\r\n \r\nKhách tham quan cũng có thể ngồi thuyền ngắm cảnh sông Áp Lục, tới gần biên giới Triều Tiên. Hai phụ nữ đang chỉ tay về hướng Sinuiju, bên trong là du khách đứng sát cửa sổ kính ngắm nhìn biên giới Triều Tiên. \r\nMột đôi tình nhân đang chụp ảnh cưới trên thuyền qua sông Áp Lục.\r\nKhách Trung Quốc ngoái đầu nhìn con thuyền chở người dân Triều Tiên sang biên giới qua sông Áp Lục.\r\nMột phụ nữ bán đồ ăn vặt Triều Tiên cho khách Trung Quốc.\r\n \r\nNgười qua đường vây quanh một thầy bói Trung Quốc, phía sau là cầu Hữu Nghị và cầu Gãy.', 'http://img.f29.vnecdn.net/2017/04/24/1-1492995827_680x0.jpg'),
(9, 'Nơi bất kỳ du khách nào đến cũng trở thành tỷ phú', '2017-04-27 11:43:52', 1, 1, 'Khi đi du lịch, bạn chỉ cần có hộ chiếu để đổi ngoại tệ. Nhưng nếu đến Somaliland, một quốc gia châu Phi không được công nhận trên thế giới, du khách cần phải mang thêm một chiếc xe thồ nếu có ý định đổi tiền.\r\n\r\nnoi-bat-ky-du-khach-nao-den-cung-tro-thanh-ty-phu\r\nTại Somaliland, việc người dân dùng xe đẩy chở tiền hay thùng to đựng tiền là điều không hề lạ lẫm. Ảnh: BBC.\r\nTheo BBC, đồng shilling Somaliland có giá trị rất thấp, chỉ đáng giá vài xu nếu đổi sang đồng USD. Do vậy, dù trả tiền một bữa ăn nhỏ, du khách cũng phải đưa cho chủ nhà hàng một xấp tiền dày và to như... cục gạch.\r\n\r\n\"Thậm chí nếu đi đường có thấy tiền rơi, người dân cũng chẳng bao giờ nhặt\", một du khách tiết lộ.\r\n\r\nCũng chính vì giá trị tiền tệ quá nhỏ, người dân Somaliland thường mang tiền ra bán cho du khách như một thứ quà lưu niệm.\r\n\r\nNơi tập trung nhiều quầy hàng bán tiền nhất là khu chợ ở thủ đô Hargeisa. Đây cũng là nơi thu hút đông du khách. Người dân và du khách mua bán công khai. Đồng tiền được chấp nhận trong các giao dịch này là euro, bảng Anh và USD.\r\n\r\nDọc hai bên đường, bạn dễ dàng bắt gặp các quầy hàng xếp san sát nhau, phía trên là các cọc tiền được buộc lại thành từng bó lớn. Họ bán tiền theo kg, một số thương nhân thậm chí còn có tới hàng trăm kg tiền nội địa để bán cho du khách.\r\n\r\n\r\nTại chợ tiền Bakaara, người dân bán đồng nội tệ đơn giản như bán mớ rau.\r\n\r\nMột du khách nói trên BBC: \"Tôi đưa cho họ 100 USD và được trao lại một bao tải đồng shilling Somaliland. Việc sở hữu quá nhiều tiền khiến tôi cảm giác mình như một tỷ phú\".\r\n\r\nNhiều du khách cũng cho biết họ khá sốc khi tới Somaliland, sau khi trải qua những ngày căng thẳng tại Mogadishu. Trái ngược với sự hỗn loạn của thủ đô Somali, Somaliland là một vùng đất yên bình, an toàn và không hề bạo động. Nơi đây được kiểm soát rất tốt bởi quân đội.\r\n\r\nChính quyền địa phương cũng thúc đẩy ngành công nghiệp du lịch để mang lại lợi nhuận cho hơn 3,5 triệu dân. Do vậy khi tới Somaliland, du khách luôn được chào đón bởi sự ấm áp, thân thiện của người dân và môi trường an toàn.\r\n\r\nCác thành phố đang được xây dựng và phát triển, nhiều nhà hàng mới, quán cafe internet, khách sạn mọc lên để phục vụ khách quốc tế. Cuộc sống dần nhộn nhịp hơn, tuy nhiên người dân còn nghèo. \r\n\r\n\r\n Điều giúp Somaliland ghi điểm trong mắt du khách quốc tế là sự thân thiện của người dân bản địa. Video: Integration TV & Real Video.\r\n\r\nĐối với những người yêu thích lịch sử, các thành phố đổ nát với hàng nghìn năm tuổi dọc theo bờ biển ở khu vực này là điểm đến lý tưởng. Ngoài ra, bạn cũng có thể khám phá các khu rừng rậm rạp tại vùng núi Cal Madow, nơi sinh sống của nhiều loài động vật hoang dã quý hiếm.', 'http://img.f33.dulich.vnecdn.net/2017/04/26/1-8115-1493199415.jpg'),
(10, '32 đội tranh tài trong vòng chung kết Robocon 2017', '2017-04-27 11:44:49', 1, 1, 'Ngày 27/4, Ban Khoa giáo Đài truyền hình Việt Nam tổ chức họp báo về vòng chung kết cuộc thi sáng tạo Robot Việt Nam (Robocon 2017). Qua vòng sơ loại, đến vòng chung kết sẽ có 32 đội tuyển đến từ 10 đại học, cao đẳng và trung cấp chuyên nghiệp thi tài.\r\n\r\n32-doi-tranh-tai-trong-vong-chung-ket-robocon-2017\r\nÔng Đỗ Quốc Khánh thông tin vòng chung kết Robocon 2017 sẽ diễn ra từ 9/5 đến 14/5 tại Ninh Bình. Ảnh: Thanh Tâm\r\nCuộc thi Robocon năm nay có tên gọi “Chinh phục đĩa bay”, dựa trên một trò chơi dân gian của Nhật Bản, đất nước đăng cai tổ chức cuộc thi Robocon châu Á - Thái Bình Dương năm 2017.\r\n\r\nCác trận đấu trong Robocon - Chinh phục đĩa bay sẽ có tính tương tác cao, hấp dẫn về mặt hình ảnh khi robot phải chinh phục các khu vực đáp đĩa. Sân thi đấu sẽ có 7 vị trí đáp đĩa với các cột có độ cao riêng. Mỗi vị trí có một quả bóng đặt trên đó. Nhiệm vụ của các robot là ném đĩa chính xác để làm rơi quả bóng, sau đó ném các đĩa lên khu vực đáp đĩa để ghi điểm.\r\n\r\nVới đề thi năm nay, yếu tố quan trọng để robot chinh phục các vị trí đáp đĩa là phải có cơ cấu bắn đĩa chuẩn xác. Anh Nguyễn Việt Phú, thành viên ban điều hành và tổ chức thi đấu vòng loại, nhận định các đội tuyển dự thi năm nay có những thiết kế robot rất thông minh, đáp ứng tốt yêu cầu của đề thi.\r\n\r\nAnh Phú cho biết vòng loại cho thấy đội tuyển đến từ các trường có truyền thống thi đấu Robocon như Đại học Sao Đỏ, Lạc Hồng hay Sư phạm Kỹ thuật Hưng Yên vẫn thể hiện tốt sức mạnh. \"Tuy nhiên, chất lượng robot của các đội có thể thay đổi trong thời gian từ vòng loại đến vòng chung kết nên khó dự đoán kết quả\", anh Phú nói và thông tin thêm Cao đẳng Công nghiệp Quốc phòng là một ẩn số khi lần đầu tham dự đã tiến nhanh vào vòng chung kết.\r\n\r\n32-doi-tranh-tai-trong-vong-chung-ket-robocon-2017-1\r\nHình ảnh trong trận chung kết Robocon năm 2016. Ảnh: BTC\r\nNói về điểm mới của cuộc thi năm nay, ông Đinh Đắc Vĩnh, Trưởng ban giám khảo, cho biết thay vì những động tác quen thuộc như bê, đỡ, đặt thì robot năm nay phải thực hiện động tác ném đĩa. \"Động tác mới này buộc các đội tuyển phải đưa ra những giải pháp công nghệ mới sao cho robot hoạt động hiệu quả nhất với chi phí thấp nhất có thể\", ông Vĩnh nói. \r\n\r\nBên cạnh đó, nếu như mọi năm, các đội tuyển thường phải chuẩn bị hai robot bao gồm robot điều khiển bằng tay và robot tự động thì năm nay, các đội chỉ phải thiết kế một robot và được toàn quyền lựa chọn loại robot phù hợp với chiến thuật và năng lực của từng đội.\r\n\r\nTrưởng ban Khoa giáo Đài truyền hình Việt Nam, Phó ban tổ chức vòng chung kết Robocon 2017, ông Đỗ Quốc Khánh cho biết để đáp ứng chủ đề năm nay, ekip sản xuất chương trình được trang bị thiết bị máy quay kỹ thuật số tốc độ cao giúp khán giả nhìn rõ hơn cơ cấu bắn đĩa của robot, quỹ đạo đĩa hay độ xoáy của đĩa khi va chạm. “Ban tổ chức sẽ phát video trực tiếp từ sân thi đấu trên mạng xã hội nhằm hướng đến đối tượng khán giả trẻ”, ông Khánh nói.', 'http://img.f29.vnecdn.net/2017/04/27/IMG-4549-JPG-4350-1493286720.jpg'),
(11, 'Siêu vũ khí của Tesla có thể xóa sổ cả đạo quân từ hàng trăm km', '2017-04-27 11:46:11', 1, 1, 'Thứ năm, 27/4/2017 | 12:00 GMT+7 |\r\nSiêu vũ khí của Tesla có thể xóa sổ cả đạo quân từ hàng trăm km\r\nNhà bác học thiên tài Nikola Tesla từng ấp ủ chế tạo \"tia tử thần\", vũ khí có thể quét sạch 10.000 máy bay và một triệu quân ở khoảng cách hàng trăm km.\r\nSức mạnh hủy diệt của vũ khí hạt nhân  /  Tại sao \'Mẹ của các loại bom\' nổ trên không thay vì dưới đất?\r\nsieu-vu-khi-cua-tesla-co-the-xoa-so-ca-dao-quan-tu-hang-tram-km\r\nTeleforce có thể được đặt trên một tòa tháp Tesla. Ảnh: Science ABC.\r\n\"Tia tử thần\" là vũ khí hủy diệt thường xuất hiện trong tác phẩm khoa học viễn tưởng. Nhiều quốc gia từng ấp ủ tham vọng chế tạo được tia tử thần, nhưng chưa có ai thành công.\r\n\r\nNgười tiến gần nhất tới mẫu tia tử thần hoàn thiện là nhà khoa học Nikola Tesla. Những phát minh kỳ diệu của ông luôn đi trước thời đại, từ ý tưởng tạo nguồn năng lượng miễn phí từ nguyên tử tự do đến thiết bị được coi là hệ thống mạng không dây sử dụng sóng vô tuyến (WiFi) trong thập niên 1920.\r\n\r\nMột trong những phát minh lớn nhất được Tesla ấp ủ là Teleforce, siêu vũ khí phát ra tia tử thần có thể tiêu diệt 10.000 máy bay và một triệu lính bộ binh từ cách hàng trăm km, nhằm mục đích bảo vệ hòa bình và ngăn chặn chiến tranh, theo Oddly Historical.\r\n\r\nBộ phát tia tử thần này có 4 thành phần, bao gồm thiết bị tạo chùm tia điện từ trong không khí, máy phát điện công suất lớn, bộ khuếch đại năng lượng và thiết bị tạo xung điện mạnh.\r\n\r\nVũ khí này được thiết kế lắp đặt ở các vị trí chiến lược dọc biên giới và bờ biển, trong khi biến thể nhỏ hơn có thể trang bị trên thiết giáp hạm.\r\n\r\nChùm tia điện từ của Tesla không phải tia laser như nhiều người lầm tưởng. Chúng là một chùm hạt vonfram siêu nhỏ được phóng đi bằng lực điện từ, giúp chùm tia hội tụ trong thời gian dài. Chùm tia này có thể ngắm bắn bằng kính viễn vọng, trên lý thuyết có thể tiêu diệt mọi thứ trong tầm quan sát. Ưu điểm của tia tử thần Tesla là đảm bảo yếu tố bí mật, khiến mục tiêu biến mất không dấu vết.', 'http://img.f29.vnecdn.net/2017/04/26/teleforce-001-1890-1493201267.jpg'),
(12, 'Chuột mang gông sắt như phạm nhân trung cổ gây sốt mạng', '2017-04-27 11:48:08', 1, 1, 'Lee Wei-chin, sống ở thành phố Đài Trung, đảo Đài Loan (Trung Quốc), bắt được một con chuột nhiều lần phá phách trong nhà và quyết định trừng phạt nó bằng biện pháp thời trung cổ, Express hôm qua đưa tin.\r\n\r\nLee chia sẻ bức ảnh chụp con chuột đeo một chiếc gông sắt trên cổ, 4 chân bị cùm bằng xích sắt với chú thích \"Cuối cùng tôi cũng bắt được nó!\" lên mạng xã hội, thu hút hàng nghìn lượt thích, chia sẻ và bình luận.\r\n\r\nMột số bình luận bày tỏ sự thương cảm cho con vật bị xiềng xích. \"Hãy giết nó hoặc thả nó đi\", một người dùng mạng xã hội kêu gọi. Dù nguồn gốc của chiếc gông sắt chưa được xác định rõ, nhiều người suy đoán nó do Lee tự làm, chứng tỏ chủ nhà quyết tâm bắt sống và trừng phạt con vật. Lee cho biết anh đã thả con chuột đi trong ngày.\r\n\r\nGông cùm là hình phạt được sử dụng rộng rãi thời xưa ở Trung Quốc cũng như châu Âu, trong đó phạm nhân bị khóa chặt ở những lỗ tròn trên phiến gỗ bọc sắt, rồi bị đem đi diễu phố, chịu sự nhạo báng của người qua đường.', 'http://img.f29.vnecdn.net/2017/04/27/VNE-Rat-2-2144-1493261611.jpg'),
(13, 'Quân đội Mỹ muốn kích não người để tạo ra siêu chiến binh', '2017-04-27 11:48:34', 1, 1, 'Cơ quan Nghiên cứu Các dự án phòng thủ Tiên tiến (DARPA) của Mỹ đang đầu tư vốn cho chương trình Huấn luyện Hệ thần kinh có mục đích (TNT). Mục tiêu là nghiên cứu sử dụng điện kích thích não bộ, cải thiện khả năng học tập và tăng tốc độ huấn luyện cho binh sĩ Mỹ, Gizmodo hôm nay đưa tin.\r\n\r\nNếu thành công, TNT sẽ giúp người lính nhanh chóng hoàn thiện các kỹ năng phức tạp, vốn đòi hỏi hàng nghìn giờ huấn luyện, điển hình là việc học ngoại ngữ. DARPA đã cấp vốn cho 8 dự án khác nhau để phục vụ chương trình TNT.\r\n\r\nCác nhà khoa học đang tìm hiểu cơ cấu sinh hóa giúp bộ não dễ thích nghi với việc học khi được kích thích. Hiệu ứng này được Đại học Texas nghiên cứu, sau khi nhận khoản đầu tư 8,5 triệu USD từ DARPA. Một nhóm sẽ làm việc với chuyên gia phân tích tình báo và ngoại ngữ để tối ưu hóa quy trình học.\r\n\r\nDARPA đang so sánh giữa kỹ thuật cấy ghép thiết bị trực tiếp vào não bộ với kích thích bên ngoài, nhằm tránh nguy hiểm cho tính mạng binh sĩ, cũng như các tác dụng không mong muốn trong khi thử nghiệm.\r\n\r\nTNT được cho là sẽ kéo dài trong 4 năm. DARPA muốn biện pháp kích thích này tăng ít nhất 30% kết quả học tập, huấn luyện cho binh sĩ.', 'http://img.f29.vnecdn.net/2017/04/27/TNT-Concept-619-316-1454-1493262745.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`) VALUES
(1, 'admin', '1234'),
(3, 'admin1', '1234'),
(4, 'admin4', '1234'),
(5, 'admin7', '1234'),
(6, 'admin8', '1234'),
(7, 'admin0', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
