-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2017 at 03:54 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Trong nước'),
(2, 'Quốc tế'),
(4, 'Văn hóa'),
(5, 'Thể thao'),
(6, 'Công nghệ'),
(7, 'Quân sự'),
(8, 'Tự sự');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL DEFAULT '1',
  `category_id` int(11) NOT NULL DEFAULT '1',
  `content` text,
  `thumbnail` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `time`, `user_id`, `category_id`, `content`, `thumbnail`) VALUES
(1, 'Real - Barca: Chiến cuộc cuối cùng của chiến binh Luis Enrique', '2017-04-26 13:46:43', 1, 1, 'Bạn có biết bộ phim nổi tiếng \"300\" do Zack Snyder đạo diễn là một sản phẩm... chém gió quá đà? Không như trên phim, trận chiến Thermopylae có đến 7.000 người Hy Lạp tham chiến. Sau khi bị phản bội, Vua Leonidas quả là có ở lại chặn quân Ba Tư cùng với 300 chiến binh Spartan. Nhưng bên cạnh đó còn có 700 người Thespian, 400 người Theban và mấy trăm quân của các thành bang Hy Lạp khác. Để trận đánh thêm phần bi tráng, các nhà biên kịch ở Hollywood chỉ giữ lại 300 quân Spartan mà thôi.\r\n\r\nNhưng lịch sử thực sự đã chứng kiến có cuộc chiến khác của 300 chiến binh đấu lại thiên binh vạn mã, diễn ra vào năm 722. Lãnh đạo cuộc khởi nghĩa là Don Pelayo, quý tộc người Visigoth đã khai sinh Vương quốc Asturias (tiền thân của nước Tây Ban Nha ngày nay). Bị dồn lên núi Auseva nhưng Don Pelayo và tàn binh của ông kiên quyết không hạ vũ khí. Họ đánh đến cùng và khi tàn cuộc, Pelayo vẫn sống, bên cạnh 10 người của quân mình. Và ở ngọn núi lịch sử năm nào, người ta đã dựng một bức tượng của Pelayo, tay cầm thanh gươm với gương mặt can trường, tự hào và bất khuất.\r\n\r\nVì sao trước một trận El Clasico lại kể truyện lịch sử? Vì Luis Enrique chính là một người Asturia.\r\n\r\nKhi Barcelona đến sân Real Madrid, dường như Enrique thấy mình đang rơi vào tình thế của Pelayo ngày trước. Barca đã bị loại khỏi Champions League, thất bại ở El Clasico sẽ chấm dứt nốt hy vọng của họ tại La Liga. Khi ấy, hàng vạn mũi giáo của truyền thông sẽ xiên vào người ông. Nhưng sự can trường là điều ta có thể thấy ở Enrique.\r\n\r\n\"Sau một thất bại, thật khó để kích thích các cầu thủ. May thay đối thủ tiếp theo lại là Real Madrid\", Enrique nói. \"Tôi là một chiến binh, tôi chuẩn bị cho mọi thứ, đặc biệt là những thứ gian khó. Tôi có gene của người Asturia, tôi có gene của Pelayo. Tôi cảm thấy thoải mái hơn khi bị rơi vào thế phải phản kháng. Tôi sẽ tận hưởng trận đấu này, vì tôi cảm thấy thoải mái hơn khi thấy mình đứng trong một cuộc chiến\".\r\n\r\nreal-barca-chien-cuoc-cuoi-cung-cua-chien-binh-luis-enrique-1\r\nEnrique và các học trò đang ở vào một tình thế ngặt nghèo, khi chỉ còn mỗi La Liga để níu giữ cho mùa giải này.\r\nVà đấy không chỉ là một cuộc chiến thông thường, nó là cuộc chiến lớn nhất lịch sử bóng đá thế giới, được đặt vào tình thế ngặt nghèo nhất, nơi triều đại của Enrique ở Barca đang đi vào hồi cuối. Và Enrique lại là người cũ của Real. Không có một sự nhân từ nào từ các khán đài dành cho kẻ phản bội trong chuyến trở về này.\r\n\r\nThực tế thì Enrique luôn cảm thấy... thoải mái khi bị các Madrisita xem như kẻ phản bội. Ông bảo khi nhìn lại những bức ảnh ngày cũ thuở còn đá cho Real, ông đã không nhận ra chính mình: \"Tôi thấy màu áo xanh-đỏ (Barca) hợp với mình hơn nhiều\".', 'http://img.f32.vnecdn.net/2017/04/26/ongthamphan-1493190052_500x300.jpg'),
(2, 'Triều Tiên tuyên bố sẵn sàng đánh chìm tàu sân bay Mỹ', '2017-04-26 13:47:12', 1, 1, 'Tổng thống Mỹ Donald Trump trong tháng 4 ra lệnh điều nhóm tác chiến tàu sân bay USS Carl Vinson tới gần bán đảo Triều Tiên để ứng phó với căng thẳng gia tăng liên quan đến Triều Tiên. Phó tổng thống Mỹ Mike Pence ngày 22/4 nói cụm tàu sẽ đến nơi \"trong vài ngày tới\" và không nêu chi tiết.\r\n\r\n\"Các lực lượng cách mạng của chúng ta sẵn sàng chiến đấu để đánh chìm một tàu sân bay hạt nhân Mỹ chỉ bằng một đòn\", Rodong Sinmun, tờ báo của đảng Lao động Triều Tiên, hôm nay cho biết trong một bài bình luận.\r\n\r\nBài bình luận ví USS Carl Vinson là \"loài vật to béo\" và tấn công con tàu là \"ví dụ thực tế để phô diễn sức mạnh quân sự\". Bài được đăng trên trang thứ ba của tờ báo, sau hai trang viết về nhà lãnh đạo Kim Jong-un.\r\n\r\nNhóm tác chiến tàu sân bay USS Carl Vinson\r\n\r\n\r\nTriều Tiên sẽ kỷ niệm 85 năm ngày thành lập Quân đội Nhân dân vào ngày 25/4. Nhiều chuyên gia cho rằng Bình Nhưỡng có thể thử hạt nhân hoặc tên lửa vào dịp này. Triều Tiên đã thử hạt nhân 5 lần và phóng thử nhiều tên lửa đạn đạo.\r\n\r\nTổng thống Trump tuyên bố sẽ ngăn Triều Tiên đạt được khả năng tấn công Mỹ bằng tên lửa hạt nhân, cảnh báo không loại trừ biện pháp nào, kể cả tấn công quân sự. Triều Tiên cũng dọa tấn công hạt nhân Mỹ nếu Washington có hành động khiêu khích.', 'http://img.f32.vnecdn.net/2017/04/26/chu-tich-nuoc-2-7581-1493202077_500x300.jpg'),
(3, 'Apple Watch 3, iPhone mới sẽ dùng màn hình micro LED', '2017-04-26 13:48:03', 1, 1, 'Theo Business Korea, Apple đang làm việc với LuxVue để phát triển và ứng dụng màn hình micro LED mới, sau khi mua lại công ty này từ năm 2014.\r\n\r\nMicro LED được đánh giá là công nghệ đột phá, sở hữu các đặc tính như nhẹ hơn, mỏng hơn và hiển thị tốt hơn so với các dòng màn hình hiện nay. Trước thương vụ của Apple, hầu như chưa được ai biết đến công nghệ này.\r\n\r\napple-watch-3-iphone-moi-se-dung-man-hinh-micro-led\r\nCông nghệ micro LED sẽ là hướng đi của Apple trong tương lai. Ảnh minh họa.\r\nTháng 2/2017, Apple đã đăng ký bằng sáng chế tích hợp đầu đọc vân tay lên bề mặt màn hình micro LED nhờ đưa vào các cảm biến diot hồng ngoại. Đây được xem là giải pháp giúp tích hợp Touch ID lên màn hình mà hãng ấp ủ từ lâu.\r\n\r\niPhone 8 dự kiến trình làng cuối năm nay có thể sẽ áp dụng công nghệ tương tự. Tuy nhiên, những khó khăn trong việc sản xuất micro LED cỡ lớn có thể khiến điều này bị trì hoãn. Trước đó, micro LED sẽ được mang lên Apple Watch 3.\r\n\r\nĐộng thái của Apple cũng cho thấy iPhone đời mới dùng màn hình OLED có thể chỉ là bước đi tạm thời trước khi hãng áp dụng công nghệ micro LED.\r\n\r\napple-watch-3-iphone-moi-se-dung-man-hinh-micro-led-1\r\nApple Watch 3 có thể là sản phẩm đầu tiên của Apple dùng màn hình micro LED. Ảnh minh họa.\r\nHơn nữa, công ty công nghệ Mỹ sẽ không mua màn hình OLED từ Samsung mà chuyển sang sản xuất ở Trung Quốc. Ngoài việc mất đi hợp đồng cung ứng trị giá hàng tỷ USD, Samsung và LG cũng đứng trước lo ngại khi Apple bắt đầu tìm nguồn cung cấp RAM hay camera từ các đối tác khác.\r\n\r\nThông báo cho biết Apple đang đàm phán mua lại bộ phận kinh doanh chip nhớ của Toshiba, chấm dứt hai thập kỷ trở thành khách hàng lớn nhất của Samsung.\r\n\r\nGiới công nghệ Hàn Quốc cho rằng nỗ lực tăng cường tự sản xuất các thành phần và đa dạng hóa các nhà cung ứng sẽ ảnh hưởng nghiêm trọng đến ngành công nghiệp của nước này. Apple hiện mua 2,63 tỷ USD linh kiện từ Hàn Quốc.\r\n\r\nNguồn lợi từ Apple cho các công ty Hàn Quốc có thể sẽ kết thúc trong 2-3 năm tới, phần lớn do chịu cạnh tranh từ Trung Quốc trong lĩnh vực bán dẫn và màn hình.', 'http://img.f7.sohoa.vnecdn.net/2017/04/26/476517-applewatch-2880-1493180722_180x108.jpg'),
(4, '14.000 công ty dùng Facebook làm nền tảng kết nối', '2017-04-26 13:48:33', 1, 1, 'Sau 6 tháng ra mắt chính thức, Facebook Workplace đã thu hút 14.000 doanh nghiệp và tổ chức sử dụng với hơn 400.000 nhóm được tạo ra.\r\nWorkplace là nền tảng truyền thông chuyên biệt, giúp người dùng trong một công ty kết nối, giao tiếp nội bộ và hợp tác với nhau trong công việc. Bắt đầu được thử nghiệm từ năm 2015 với tên gọi Facebook At Work, Workplace chính thức ra mắt vào tháng 10/2016 với hơn 1.000 doanh nghiệp đăng ký sử dụng. \r\n\r\nTại hội thảo F8, diễn ra tuần trước ở San Jose (Mỹ), Facebook công bố sau sáu tháng, số lượng tổ chức, doanh nghiệp sử dụng đã tăng lên 14.000 với hơn 400.000 nhóm được tạo ra. \r\n\r\nÔng Ramesh Gopalkrishna, Phụ trách khu vực châu Á - Thái Bình Dương của Facebook, cho biết nền tảng này tích hợp sâu với các dịch vụ như Box, Office 365, Dropbox, Salesforce/Quip. Nhờ đó, người dùng không cần tải file lên một dịch vụ lưu trữ rồi dán đường link vào nhóm Facebook, mà họ có thể chia sẻ file trực tiếp để đồng nghiệp nhanh chóng bấm vào xem, chỉnh sửa và bình luận. \r\n\r\nBên cạnh bản thu phí Workplace Premium với giá 1-3 USD/người dùng mỗi tháng, Facebook mới đây cũng trình làng gói Workplace Standard miễn phí cho cho doanh nghiệp nhỏ.', 'http://img.f5.sohoa.vnecdn.net/2017/04/25/FB-9189-1493110052.jpg'),
(5, 'Galaxy Note 7 sắp được bán trở lại với giá 620 USD', '2017-04-26 13:48:58', 1, 1, 'Để phân biệt với phiên bản cũ, Galaxy Note 7 tân trang sẽ được gọi với tên Note 7R (Refurbished). Máy giảm dung lượng pin từ 3.500 mAh xuống còn 3.200 mAh, theo PhoneArena.\r\n\r\ngalaxy-note-7-sap-duoc-ban-tro-lai-voi-gia-620-usd\r\nNote 7 sẽ trở lại thị trường Hàn Quốc dưới dạng hàng tân trang, giá giảm 30%.\r\nPhần cứng và ngoại hình của Note 7 tân trang được cho là không thay đổi. Máy dùng màn hình Quad HD 5,7 inch Super Amoled, bộ xử lý Exynos 8890, RAM 4 GB, bộ nhớ trong 64 GB và camera 12 megapixel.\r\n\r\nMức giá cho Galaxy Note 7R tại thị trường Hàn Quốc là 620 USD (khoảng 14 triệu đồng), giảm 30% so với giá 875 USD (khoảng 20 triệu đồng) của Note 7 trước đây.\r\n\r\nTại Việt Nam, Note 7 lên kệ tháng 8/2016 với giá 19 triệu đồng. Nếu áp mức giảm tương tự 30%, phiên bản tân trang có thể được bán trong nước giá 13,3 triệu đồng.\r\n\r\nTuy nhiên, chưa có thông tin về việc Note 7R được bán tại Việt Nam. Trao đổi với VnExpress vào tháng 2/2017, đại diện Samsung Việt Nam cho biết hãng hiện không có kế hoạch bán Galaxy Note 7 tân trang.', 'http://img.f5.sohoa.vnecdn.net/2017/04/26/galaxy-note-7-1-1896-1493194752.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`) VALUES
(1, 'admin', '1234'),
(3, 'admin1', '1234'),
(4, 'admin4', '1234'),
(5, 'admin7', '1234'),
(6, 'admin8', '1234'),
(7, 'admin0', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
